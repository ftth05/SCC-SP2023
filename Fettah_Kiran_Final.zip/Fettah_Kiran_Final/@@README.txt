// Name: Fettah Kiran
// UHID: 1678975
// Final Project


To run each question, use following lines

g++ Q1.cpp -o Q1
g++ Q2.cpp -o Q2
g++ Q3.cpp -o Q3
g++ Q4.cpp -o Q4

