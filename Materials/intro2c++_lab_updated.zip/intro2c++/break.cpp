#include  <iostream> 
using namespace std; 
int main()
{
  int i=0;
//  for ( i=0; i<=10; i=i+2)
// for ( i=0; i<=10; i+=2)
 for (;;)
  {  
     if  (i >5) {  break;  }
     cout << "What a wonderful class!"<<endl;
     i+=2;
  }
  return  0;
}
