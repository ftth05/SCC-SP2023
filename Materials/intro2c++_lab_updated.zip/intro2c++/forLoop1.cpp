#include  <iostream> 
using namespace std; 
int main()
{
  int i;
  for ( i=0; i<3; i++)
  {  
     cout << "What a wonderful class!"<<endl;
  }
  return  0;
}
