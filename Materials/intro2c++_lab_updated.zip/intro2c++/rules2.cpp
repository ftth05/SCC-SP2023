/*
*   rules2.cpp
*  this  is a  multi-line  comment
*/
#include  <iostream>
 using namespace std;
 int main()
{
 /* notice  the  usage  of  endl - \n  can  also be used	*/
 cout  <<  "Braces come in pairs." << endl;
 cout  <<  "Comments come in pairs." << endl;
 cout  <<  "All statements end with semicolon." << endl;
 cout  <<  "Every program has a main function." << endl;
 return 0;
}
//this  is how single line comments are specified

