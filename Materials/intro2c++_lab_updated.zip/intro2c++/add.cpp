#include  <iostream>
using namespace std; 

void add()
{
  int a,  b,  c;
  cout  <<  "\n Enter Any 2 Numbers : ";
  cin >>  a >>  b;
  c = a + b;
  cout  <<  "\n Addition  is  : " <<  c <<endl;
}

