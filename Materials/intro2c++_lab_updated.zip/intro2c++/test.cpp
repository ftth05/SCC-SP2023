#include <iostream>
#include <cmath>

using namespace std;

int main()
{

cout.precision(16);
cout.setf(ios::fixed,ios::floatfield);

cout <<M_PI <<endl;

cout << 2/sqrt(M_PI)  <<endl;
cout << M_2_SQRTPI << endl; 
}
