#include  <iostream>
#include  <cmath> 
using namespace std; 
int main()
{
	double  x = 0;
	cout  <<  "Enter  a double  value\n";
	cin >>  x;
	cout  <<"Square root  of  " <<  x <<  " is  " <<  sqrt(x); 
	cout  <<  "\nLog  of  " <<  x <<  " is  " <<  log(x)  <<  endl;
	return  0;
}

