#include <iostream>
 
using namespace std;
int main()
{       
	
  auto welcome = []() { cout << "Welcome to world of CXX"<<endl;};

     welcome(); 
}
