#include  <iostream> 

using	namespace std ;
 
int	main()	
{
	cout	<< "Introduction to C++" << endl ;

	return 0;
}

