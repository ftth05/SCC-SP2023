
// Name: Fettah Kiran
// UHID: 1678975

/* 1.) The program prints a big letter H as H shape with 8 Hs */

#include  <iostream>
using namespace std; 


void capitalh();

int main()
{
    capitalh() ; 
    return  0;
}

void capitalh()
{
  for (int i = 0; i < 4; ++i)
  {
    if (i==2)
    {
      cout  <<  "HHHH\n";
    }
    cout  <<  "H  H \n";

  }
  
}

