
Assignment 1
Opened: Wednesday, March 22, 2023, 12:00 AM
Due: Tuesday, March 28, 2023, 5:00 PM
1.) Write a program that prints a big letter H as shown below


H  H
H  H
HHHH
H  H
H  H
  
2.)
Write a program that calculates the sales tax of a transaction given the sale amount. Assume that the tax is 9 percent. Use a constant to define the tax rate. Run your program several times, each with different values for the sale amount. Use the following format for output.



Sale amount: … 
Tax amount: … 
Total amount due: …